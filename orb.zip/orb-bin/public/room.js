const $=s=>document.querySelector(s),params=new URLSearchParams(location.search),roomId=params.get("id");
let me=null,roomInfo=null,socket=null,lkRoom=null,mediaReady=false,activePanel="members",hands=new Map(),boardMode="pen",drawing=false,last=null,selectedMember=null,canManage=false,isSiteOwner=false,ownHand=false;
async function api(url,opts={}){const r=await fetch(url,{...opts,headers:{"Content-Type":"application/json",...(opts.headers||{})}});let d={};try{d=await r.json()}catch{}if(!r.ok)throw Error(d.error||"خطا");return d}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function avatarClass(m){if(m.role==="site_owner")return "avatar-owner";if(m.role==="teacher")return "avatar-teacher";const n=Object.values(m.permissions||{}).filter(Boolean).length;return n>=3?"avatar-presenter":n?"avatar-enabled":"avatar-student"}
function roleLabel(m){return m.role==="site_owner"?"مالک کل سایت":m.role==="teacher"?"مدرس":Object.values(m.permissions||{}).some(Boolean)?"عضو ویژه":"دانش‌آموز"}
async function start(){if(!roomId){alert("شناسه کلاس نامعتبر است");location.href="/";return}try{
  if(params.get("invite")) await api(`/api/rooms/${encodeURIComponent(roomId)}/invite-join`,{method:"POST",body:JSON.stringify({code:params.get("invite")})});
  const meD=await api("/api/me");me=meD.user;isSiteOwner=!!meD.siteOwner;
  const d=await api("/api/rooms/"+encodeURIComponent(roomId));roomInfo=d;$("#roomTitle").textContent=d.room.title;canManage=!!(d.siteOwner||d.me?.role==="teacher"||d.me?.permissions?.members===true);
  renderMembers(d.members);renderTools(d.me,d.siteOwner);setupShare(d.inviteUrl);const polls=await api(`/api/rooms/${roomId}/polls`).catch(()=>({polls:[]}));(polls.polls||[]).forEach(showPoll);const msg=await api("/api/rooms/"+roomId+"/messages").catch(()=>({messages:[]}));(msg.messages||[]).forEach(addMessage);connectSocket();setupBoard();await connectMedia();
}catch(e){if(/وارد حساب|نشست|احراز هویت/.test(e.message))location.href="/?next="+encodeURIComponent(location.pathname+location.search);else{alert(e.message);location.href="/"}}}
function renderTools(m,siteOwner){
 const perms=m?.permissions||{};
 const isTeacher=m?.role==="teacher"||m?.role==="site_owner"||siteOwner;
 const allowedTools={microphone:isTeacher||perms.microphone===true,camera:isTeacher||perms.camera===true,screen:isTeacher||perms.screen===true,whiteboard:isTeacher||perms.whiteboard===true,members:isTeacher||perms.members===true,chat:isTeacher||perms.chat===true,polls:isTeacher||perms.polls===true};
 document.querySelectorAll("[data-tool]").forEach(b=>{
   const key=b.dataset.tool,show=!!allowedTools[key];
   b.classList.toggle("hidden",!show);
   b.disabled=!show;
   b.onclick=()=>toolAction(key,b);
 });
 const hand=$("#raiseHand");
 hand.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 12V5a1.5 1.5 0 0 1 3 0v6-8a1.5 1.5 0 0 1 3 0v8-6a1.5 1.5 0 0 1 3 0v7-4a1.5 1.5 0 0 1 3 0v7c0 5-3 8-8 8h-1c-3 0-5-2-6-4l-3-5a1.7 1.7 0 0 1 3-2z"/></svg>';
 hand.title=ownHand?"پایین آوردن دست":"بالا بردن دست";hand.setAttribute("aria-label",hand.title);
 hand.classList.toggle("active",ownHand);
 hand.onclick=()=>{ownHand=!ownHand;hand.classList.toggle("active",ownHand);hand.title=ownHand?"پایین آوردن دست":"بالا بردن دست";hand.setAttribute("aria-label",hand.title);socket?.emit("hand:raise",{roomId,raised:ownHand},r=>{if(r?.error)alert(r.error)})};
}
async function toolAction(key,button){try{if(["microphone","camera","screen"].includes(key)){if(!mediaReady||!lkRoom?.localParticipant)throw Error("اتصال رسانه هنوز آماده نیست؛ چند لحظه صبر کنید.");const lp=lkRoom.localParticipant;if(key==="microphone"){if(!navigator.mediaDevices?.getUserMedia)throw Error("مرورگر به میکروفن دسترسی ندارد. صفحه را با HTTPS و مرورگر به‌روز باز کنید.");const on=!lp.isMicrophoneEnabled;await lp.setMicrophoneEnabled(on);button.classList.toggle("active",on)}else if(key==="camera"){if(!navigator.mediaDevices?.getUserMedia)throw Error("مرورگر به دوربین دسترسی ندارد. مجوز دوربین را در تنظیمات سایت فعال کنید.");const on=!lp.isCameraEnabled;await lp.setCameraEnabled(on);button.classList.toggle("active",on)}else{if(!navigator.mediaDevices?.getDisplayMedia)throw Error("اشتراک صفحه در این مرورگر یا دستگاه پشتیبانی نمی‌شود. از مرورگر دسکتاپ و HTTPS استفاده کنید.");await lp.setScreenShareEnabled(!lp.isScreenShareEnabled);button.classList.toggle("active",lp.isScreenShareEnabled)}}else if(key==="whiteboard")$("#whiteboard").classList.toggle("hidden");else if(key==="members")$("[data-panel=members]").click();else if(key==="chat")$("#messages").scrollIntoView({behavior:"smooth"});else if(key==="polls")$("#pollModal").classList.remove("hidden");}catch(e){alert(e.message||"عملیات رسانه انجام نشد")}}
function setupShare(url){const b=$("#shareRoom");if(!b)return;if(url){try{const u=new URL(url,location.origin);u.protocol=location.protocol;u.host=location.host;url=u.toString()}catch{}b.classList.remove("hidden");b.onclick=async()=>{try{await navigator.clipboard.writeText(url);b.textContent="✓ لینک کپی شد";setTimeout(()=>b.textContent="↗ دعوت به کلاس",1800)}catch{prompt("لینک دعوت کلاس را کپی کنید:",url)}}}}
function renderMembers(list){const count=list.length;$("#memberCount").textContent=count;$("#membersList").innerHTML=list.map(m=>{const owner=m.role==="site_owner";return `<div class="member ${canManage&&!owner?"clickable":""}" data-user="${esc(m.id)}"><span class="avatar ${avatarClass(m)}">${owner?"✦":'<svg class="avatar-icon" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="7.5" r="4"/><path d="M4.5 21c.5-4.4 3.2-7 7.5-7s7 2.6 7.5 7"/></svg>'}</span><span class="membername ${owner?"role-owner owner-name":m.role==="teacher"?"role-teacher":Object.values(m.permissions||{}).some(Boolean)?"role-enabled":"role-student"}">${esc(m.display_name)}</span><span class="rolebadge ${owner?"owner-badge":""}">${roleLabel(m)}</span>${owner?'<span class="crown">♛</span>':canManage?'<span class="membermore">•••</span>':""}</div>`}).join("")||'<p class="empty">عضوی وجود ندارد.</p>';if(canManage)$("#membersList").querySelectorAll("[data-user]").forEach(el=>el.onclick=()=>{const target=list.find(m=>String(m.id)===el.dataset.user);if(target?.role!=="site_owner")openMember(target)})}
const permissionLabels={members:"مشاهده و مدیریت اعضا",chat:"ارسال پیام در چت",whiteboard:"استفاده از تخته",microphone:"میکروفن",camera:"دوربین",screen:"اشتراک صفحه",polls:"ساخت نظرسنجی"};
function openMember(m){if(!m)return;selectedMember=m;$("#memberModalName").textContent=m.display_name;$("#permissionList").innerHTML=Object.entries(permissionLabels).map(([k,label])=>`<label class="permissionrow"><span>${label}</span><input type="checkbox" data-perm="${k}" ${m.permissions?.[k]===true?"checked":""}></label>`).join("");$("#memberError").textContent="";$("#memberModal").classList.remove("hidden")}
$("#memberClose").onclick=()=>$("#memberModal").classList.add("hidden");
$("#memberSave").onclick=async()=>{if(!selectedMember)return;const permissions={};$("#permissionList").querySelectorAll("[data-perm]").forEach(x=>permissions[x.dataset.perm]=x.checked);try{await api(`/api/rooms/${roomId}/members/${selectedMember.id}`,{method:"PATCH",body:JSON.stringify({permissions})});$("#memberModal").classList.add("hidden");const d=await api("/api/rooms/"+roomId);renderMembers(d.members)}catch(e){$("#memberError").textContent=e.message}};
$("#memberKick").onclick=async()=>{if(!selectedMember||!confirm(`عضویت ${selectedMember.display_name} حذف شود؟`))return;try{await api(`/api/rooms/${roomId}/members/${selectedMember.id}`,{method:"DELETE"});$("#memberModal").classList.add("hidden");const d=await api("/api/rooms/"+roomId);renderMembers(d.members)}catch(e){$("#memberError").textContent=e.message}};
function renderHands(){const a=[...hands.values()].filter(x=>x.raised);$("#handCount").textContent=a.length;$("#handsList").innerHTML=a.map(x=>`<div class="member"><span class="avatar avatar-hand">${esc((x.displayName||"?").slice(0,1))}</span><span class="membername">${esc(x.displayName)}　✋</span></div>`).join("")||'<p class="empty">دستی بالا نیست.</p>'}
document.querySelectorAll("[data-panel]").forEach(b=>b.onclick=()=>{activePanel=b.dataset.panel;document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===b));$("#membersList").classList.toggle("hidden",activePanel!=="members");$("#handsList").classList.toggle("hidden",activePanel!=="hands")});
function connectSocket(){socket=io({withCredentials:true});socket.on("connect",()=>socket.emit("room:join",{roomId},r=>{if(r?.error)console.warn(r.error)}));socket.on("connect_error",()=>{});socket.on("chat:message",addMessage);socket.on("chat:clear",()=>$("#messages").innerHTML="");socket.on("chat:deleted",x=>document.querySelector(`[data-mid="${x.id}"]`)?.remove());socket.on("chat:edited",m=>{const el=document.querySelector(`[data-mid="${m.id}"] .body`);if(el)el.textContent=m.body});socket.on("members:refresh",async()=>{const d=await api("/api/rooms/"+roomId);roomInfo=d;canManage=!!(d.siteOwner||d.me?.role==="teacher"||d.me?.permissions?.members===true);renderMembers(d.members);renderTools(d.me,d.siteOwner)});socket.on("hands:snapshot",items=>{hands.clear();(items||[]).forEach(x=>hands.set(String(x.userId),x));ownHand=hands.has(String(me.id));$("#raiseHand").classList.toggle("active",ownHand);renderHands()});socket.on("hand:update",x=>{if(x.raised)hands.set(String(x.userId),x);else hands.delete(String(x.userId));if(String(x.userId)===String(me.id))ownHand=!!x.raised;renderHands()});socket.on("whiteboard:draw",drawRemote);socket.on("whiteboard:clear",()=>{const c=$("#boardCanvas");c.getContext("2d").clearRect(0,0,c.width,c.height)});socket.on("poll:new",p=>showPoll(p));socket.on("poll:results",r=>updatePollResults(r))}
function addMessage(m){const el=document.createElement("div");el.className="message";el.dataset.mid=m.id;const n=document.createElement("strong");n.textContent=m.display_name||"عضو";const body=document.createElement("span");body.className="body";body.textContent=m.body;el.append(n,body);$("#messages").append(el);$("#messages").scrollTop=$("#messages").scrollHeight}
$("#chatForm").onsubmit=e=>{e.preventDefault();const body=$("#chatInput").value.trim();if(!body)return;if(!socket?.connected)return alert("اتصال چت برقرار نیست.");socket.emit("chat:send",{roomId,body},r=>{if(r?.error)alert(r.error);else $("#chatInput").value=""})};
async function connectMedia(){const grid=$("#videoGrid");try{
  if(!window.LivekitClient?.Room)throw Error("فایل SDK لایو‌کیت بارگذاری نشده است. مسیر /vendor/livekit/livekit-client.umd.js را بررسی کنید.");
  if(!navigator.mediaDevices)throw Error("مرورگر API رسانه را ارائه نمی‌کند. صفحه باید با HTTPS باز شود.");
  const d=await api(`/api/rooms/${roomId}/join`,{method:"POST"});
  if(!d.serverUrl||!d.token)throw Error("اطلاعات اتصال LiveKit ناقص است؛ متغیرهای LiveKit در Render را بررسی کنید.");
  lkRoom=new LivekitClient.Room({adaptiveStream:true,dynacast:true,autoSubscribe:true});
  lkRoom.on(LivekitClient.RoomEvent.TrackSubscribed,(track,publication,participant)=>attachTrack(track,participant,false));
  lkRoom.on(LivekitClient.RoomEvent.TrackUnsubscribed,(track,publication,participant)=>removeTrack(track,participant));
  const subscribeRemotePublication=(publication)=>{
    if(!publication || publication.isSubscribed) return;
    try {
      const result=publication.setSubscribed(true);
      if(result && typeof result.catch==="function") result.catch(err=>console.warn("LiveKit subscribe failed",err));
    } catch(err) { console.warn("LiveKit subscribe failed",err); }
  };
  lkRoom.on(LivekitClient.RoomEvent.TrackPublished,(publication,participant)=>{
    if(participant!==lkRoom.localParticipant) subscribeRemotePublication(publication);
  });
  lkRoom.on(LivekitClient.RoomEvent.ParticipantConnected,participant=>{
    for(const pub of participant.trackPublications.values()) subscribeRemotePublication(pub);
  });
  lkRoom.on(LivekitClient.RoomEvent.TrackSubscriptionFailed,(trackSid,participant)=>{
    console.error("LiveKit track subscription failed", {trackSid, participant:participant?.identity});
  });
  lkRoom.on(LivekitClient.RoomEvent.ParticipantDisconnected,participant=>{document.querySelectorAll(`[data-participant="${CSS.escape(participant.identity)}"]`).forEach(el=>el.remove());});
  lkRoom.on(LivekitClient.RoomEvent.LocalTrackPublished,(pub)=>{if(pub.track)attachTrack(pub.track,lkRoom.localParticipant,true)});
  lkRoom.on(LivekitClient.RoomEvent.LocalTrackUnpublished,pub=>{if(pub.track)removeTrack(pub.track,lkRoom.localParticipant,true)});
  lkRoom.on(LivekitClient.RoomEvent.ConnectionStateChanged,state=>console.info("LiveKit state:",state));
  await lkRoom.connect(d.serverUrl,d.token);
  if(!lkRoom.localParticipant)throw Error("اتصال برقرار شد اما شرکت‌کننده محلی آماده نیست.");
  mediaReady=true;document.querySelectorAll('[data-tool="microphone"],[data-tool="camera"],[data-tool="screen"]').forEach(b=>{b.disabled=false;b.title="آماده"});grid.querySelector(".stageempty")?.remove();ensureLocalTile();
  for(const participant of lkRoom.remoteParticipants.values()) {
    for(const pub of participant.trackPublications.values()) {
      subscribeRemotePublication(pub);
      if(pub.track && pub.isSubscribed) attachTrack(pub.track,participant,false);
    }
  }
}catch(e){mediaReady=false;console.error("LiveKit connection failed",e);const old=grid.querySelector(".stageempty");if(old)old.remove();const p=document.createElement("div");p.className="stageempty media-error";p.innerHTML=`<div class="stageicon">◉</div><h2>اتصال رسانه برقرار نشد</h2><p>${esc(e.message||"خطای ناشناخته")}</p><small>تنظیمات LIVEKIT_URL، LIVEKIT_API_KEY و LIVEKIT_API_SECRET در Render را بررسی کنید.</small>`;grid.append(p)}}
function ensureLocalTile(){if(!lkRoom?.localParticipant)return;let box=document.getElementById("p-local");if(!box){box=document.createElement("div");box.className="videoitem localvideo";box.id="p-local";const label=document.createElement("span");label.textContent=me.display_name+" (شما)";box.append(label);$("#videoGrid").append(box)}}
function attachTrack(track,participant,isLocal=false){
 if(!track||!participant)return;
 if(track.kind==="audio"){
   if(isLocal)return; const audio=track.attach();audio.autoplay=true;audio.playsInline=true;audio.dataset.trackSid=track.sid;audio.style.position="fixed";audio.style.width="1px";audio.style.height="1px";audio.style.opacity="0";document.body.append(audio);audio.play?.().catch(()=>console.warn("مرورگر برای پخش صدا به تعامل کاربر نیاز دارد."));return;
 }
 const identity=String(participant.identity),safe=identity.replace(/[^a-zA-Z0-9_-]/g,"_");
 const id=`p-${safe}-${String(track.sid||track.source||"video").replace(/[^a-zA-Z0-9_-]/g,"_")}`;
 if(document.getElementById(id))return;
 const box=document.createElement("div");box.className="videoitem";box.id=id;box.dataset.participant=identity;
 const label=document.createElement("span");label.textContent=(participant.name||participant.identity)+(String(track.source).toLowerCase().includes("screen")?" · اشتراک صفحه":isLocal?" · شما":"");
 const el=track.attach();el.autoplay=true;el.playsInline=true;el.setAttribute("playsinline","");el.muted=!!isLocal;el.classList.add("orb-media-track");box.append(el,label);$("#videoGrid").append(box);$("#videoGrid").querySelector(".stageempty")?.remove();el.play?.().catch(()=>{});
}
function removeTrack(track,participant,isLocal=false){if(!track)return;track.detach().forEach(el=>el.remove());if(track.kind==="audio")return;const identity=String(participant?.identity||"");const safe=identity.replace(/[^a-zA-Z0-9_-]/g,"_");const id=`p-${safe}-${String(track.sid||track.source||"video").replace(/[^a-zA-Z0-9_-]/g,"_")}`;document.getElementById(id)?.remove()}
function setupBoard(){const c=$("#boardCanvas"),ctx=c.getContext("2d");function resize(){const r=c.getBoundingClientRect(),d=window.devicePixelRatio||1;c.width=Math.max(1,r.width*d);c.height=Math.max(1,r.height*d);ctx.setTransform(d,0,0,d,0,0)}resize();window.addEventListener("resize",resize);document.querySelectorAll("[data-board]").forEach(b=>b.onclick=()=>boardMode=b.dataset.board);function point(e){const r=c.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top}}c.onpointerdown=e=>{drawing=true;last=point(e);c.setPointerCapture(e.pointerId)};c.onpointermove=e=>{if(!drawing)return;const p=point(e),action={from:last,to:p,color:boardMode==="eraser"?"#ffffff":$("#boardColor").value,size:Number($("#boardSize").value),mode:boardMode};drawAction(ctx,action);socket?.emit("whiteboard:draw",{roomId,action});last=p};c.onpointerup=()=>drawing=false;$("#boardClear").onclick=()=>{ctx.clearRect(0,0,c.width,c.height);socket?.emit("whiteboard:clear",{roomId})};$("#boardFull").onclick=()=>$("#whiteboard").requestFullscreen?.()}
function drawAction(ctx,a){ctx.strokeStyle=a.color;ctx.lineWidth=a.size;ctx.lineCap="round";ctx.beginPath();ctx.moveTo(a.from.x,a.from.y);ctx.lineTo(a.to.x,a.to.y);ctx.stroke()}function drawRemote(a){const c=$("#boardCanvas"),ctx=c.getContext("2d");drawAction(ctx,a)}
$("#pollClose").onclick=()=>$("#pollModal").classList.add("hidden");$("#pollForm").onsubmit=async e=>{e.preventDefault();try{const options=$("#pollOptions").value.split("\n").map(x=>x.trim()).filter(Boolean);const d=await api(`/api/rooms/${roomId}/polls`,{method:"POST",body:JSON.stringify({question:$("#pollQuestion").value,options})});showPoll(d.poll);$("#pollModal").classList.add("hidden")}catch(e){alert(e.message)}};
const pollCards=new Map();
function showPoll(p){
 const id=String(p.id);let box=pollCards.get(id);if(!box){box=document.createElement("div");box.className="pollcard";box.dataset.pollId=id;pollCards.set(id,box);$("#messages").append(box)}
 const counts=p.counts||Array(p.options.length).fill(0),total=Number(p.total??counts.reduce((a,b)=>a+b,0));box.innerHTML="";
 const title=document.createElement("b");title.textContent=p.question;box.append(title);
 const summary=document.createElement("small");summary.className="poll-summary";summary.textContent=`${total} رأی`;box.append(summary);
 p.options.forEach((option,i)=>{const row=document.createElement("div");row.className="poll-option";const button=document.createElement("button");button.type="button";button.textContent=option;button.disabled=p.myVote!==undefined&&p.myVote!==null;button.onclick=async()=>{try{const result=await api(`/api/polls/${id}/vote`,{method:"POST",body:JSON.stringify({optionIndex:i})});p.myVote=i;p.counts=result.counts;p.total=result.total;showPoll(p)}catch(e){alert(e.message)}};const count=document.createElement("span");count.className="poll-count";const n=Number(counts[i]||0),pct=total?Math.round(n/total*100):0;count.textContent=`${n} نفر · ${pct}%`;row.append(button,count);const bar=document.createElement("div");bar.className="poll-bar";const fill=document.createElement("i");fill.style.width=pct+"%";bar.append(fill);row.append(bar);box.append(row)});
}
function updatePollResults(result){const box=pollCards.get(String(result.id));if(!box)return;const opts=[...box.querySelectorAll(".poll-option button")].map(b=>b.textContent);if(!opts.length)return;const p={id:result.id,question:box.querySelector("b")?.textContent||"نظرسنجی",options:opts,counts:result.counts,total:result.total,myVote:box.dataset.myVote??null};showPoll(p)}
$("#leave").onclick=async()=>{try{if(lkRoom)await lkRoom.disconnect()}finally{location.href="/"}};start();
